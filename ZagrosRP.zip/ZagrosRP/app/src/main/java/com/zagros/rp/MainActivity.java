package com.zagros.rp;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    static final int GOLD = 0xFFD4AF37, BG = 0xFF0A0A0A, GRAY = 0xFFBBBBBB;
    EditText nick;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(BG);
        int p = dp(28);
        root.setPadding(p, p, p, p);

        root.addView(label(Config.SERVER_NAME.toUpperCase(), 36, GOLD, true));
        root.addView(label("زاغروس", 18, GRAY, false));

        SharedPreferences sp = getSharedPreferences("z", 0);
        nick = new EditText(this);
        nick.setHint("اسم اللاعب (Name_Surname)");
        nick.setHintTextColor(0xFF777777);
        nick.setTextColor(0xFFFFFFFF);
        nick.setSingleLine(true);
        nick.setText(sp.getString("nick", ""));
        nick.setBackground(box(0xFF1A1A1A, 0xFF333333));
        nick.setPadding(dp(16), dp(14), dp(16), dp(14));
        root.addView(nick, lp(dp(40)));

        Button play = btn("دخول", true);
        play.setOnClickListener(v -> play(sp));
        root.addView(play, lp(dp(16)));

        if (!Config.FILES_URL.isEmpty()) {
            Button dl = btn("تحميل الملفات", false);
            dl.setOnClickListener(v -> download());
            root.addView(dl, lp(dp(12)));
        }
        setContentView(root);
    }

    void play(SharedPreferences sp) {
        String n = nick.getText().toString().trim();
        if (n.length() < 3) { toast("اكتب اسم اللاعب"); return; }
        sp.edit().putString("nick", n).apply();
        Intent i = getPackageManager().getLaunchIntentForPackage(Config.GAME_PACKAGE);
        if (i == null) { toast("اللعبة غير مثبتة"); return; }
        i.putExtra("nickname", n);
        i.putExtra("ip", Config.SERVER_IP);
        i.putExtra("port", Config.SERVER_PORT);
        startActivity(i);
    }

    void download() {
        DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
        DownloadManager.Request r = new DownloadManager.Request(Uri.parse(Config.FILES_URL));
        r.setDestinationInExternalFilesDir(this, null, "game_files.zip");
        r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        dm.enqueue(r);
        toast("بدأ التحميل");
    }

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }
    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    GradientDrawable box(int fill, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill); g.setCornerRadius(dp(12)); g.setStroke(dp(1), stroke);
        return g;
    }

    LinearLayout.LayoutParams lp(int topMargin) {
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        l.topMargin = topMargin;
        return l;
    }

    TextView label(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(color); t.setGravity(Gravity.CENTER);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    Button btn(String s, boolean filled) {
        Button b = new Button(this);
        b.setText(s); b.setTextSize(18); b.setAllCaps(false);
        b.setTextColor(filled ? BG : GOLD);
        b.setBackground(filled ? box(GOLD, GOLD) : box(0x00000000, GOLD));
        return b;
    }
}
