package com.zagros.rp;

/** غيّر القيم هنا فقط. */
public class Config {
    public static final String SERVER_NAME  = "Zagros RP";
    public static final String SERVER_IP    = "127.0.0.1";   // عنوان سيرفرك
    public static final int    SERVER_PORT  = 7777;          // بورت سيرفرك
    public static final String GAME_PACKAGE = "com.example.game"; // اسم حزمة اللعبة المثبتة
    public static final String FILES_URL    = "";            // رابط ملفاتك على استضافتك (اتركه فاضي لو ما تبي تحميل)
}
